package com.ye.tiger;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		
		System.err.println(df.format(calendar.getTime()));
		
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		
		float kk=34121797.88f;
		System.err.println(cutOff("34121797.889"));
		
		try {
			URI uri=new URI("https://phones-web.g01gameapp.com/Q04e/android/lottery/apph5/Lottery_h5.apk");
			URL url=new URL("https://phones-web.g01gameapp.com/Q04e/android/lottery/apph5/Lottery_h5.apk");
			System.out.println(url.getHost());
			System.out.println(url.getProtocol());
			System.out.println(url.getPath());
			System.out.println(uri.getHost());
			System.out.println(uri.getPath());
		} catch (MalformedURLException | URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	 //length 代表保留几位
    public static String cutOff(String val)
    {
        NumberFormat decimalFormat = DecimalFormat.getNumberInstance();
        if(val!=null)
        {
            try {
                String format = decimalFormat.format(new BigDecimal(val));
                return format;
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }

        return val;
    }
}
