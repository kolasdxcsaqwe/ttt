package me.zohar.lottery.issue.vo;

public class LotteryHistoryExtFieldVO {

}
